import * as request from 'supertest';
import { Test } from '@nestjs/testing';
import { ProjectModule } from '../../../api/src/app/project/project.module';
import { ProjectService } from '../../../api/src/app/project/project.service';
import { INestApplication } from '@nestjs/common';


describe('Project', () => {
	let app: INestApplication;
	const projectService: any ;

	beforeAll(async () => {
		const moduleRef = await Test.createTestingModule({
			imports: [ProjectModule],
		})
			.overrideProvider(ProjectService)
			.useValue(projectService)
			.compile();

		app = moduleRef.createNestApplication();
		await app.init();
	});

	
	it(`/GET projects`, () => {
		return request(app.getHttpServer())
			.get('/projects')
			.expect(200)
			.expect((res) => {
				expect(Array.isArray(res.body)).toBe(true);
			});
	});


	it('/POST a new project', () => {
		const newProject = {
			name: 'New Project',
			customer: {
				name: 'Test Customer'
			}
		};

		return request(app.getHttpServer())
			.post('/projects')
			.send(newProject)
			.expect(201)
			.expect((res) => {
				expect(res.body.name).toBe(newProject.name);
				expect(res.body.customer).toBeDefined();
			});
	});


	it(`/GET projects/:id `, () => {
		const newProject = {
			name: 'New Project',
			customer: {
				name: 'Test Customer'
			}
		};

		const createdProject = request(app.getHttpServer())
			.post('/projects')
			.send(newProject)
			.expect(201);

		return request(app.getHttpServer())
			.get(`/projects/${createdProject._id}`)
			.expect(200)
			.expect((res) => {
				expect(res.body._id).toBe(createdProject._id);
				expect(res.body.name).toBe(newProject.name);
				expect(res.body.customer).toBeDefined();
			});
	});


	it(`/DELETE projects/:id `, () => {
		const newProject = {
			name: 'New Project',
			customer: {
				name: 'Test Customer'
			}
		};

		const createdProject = request(app.getHttpServer())
			.post('/projects')
			.send(newProject)
			.expect(201);

		return request(app.getHttpServer())
			.delete(`/projects/${createdProject._id}`)
			.expect(200) // Todo
			.expect((res) => {
				expect(res.body._id).toBe(createdProject._id);
			});
	});


	it(`/PUT projects/:id `, () => {
		const newProject = {
			name: 'New Project',
			customer: {
				name: 'Test Customer'
			}
		};

		const createdProject = request(app.getHttpServer())
			.post('/projects')
			.send(newProject)
			.expect(201);

		let newName = 'Johannes';
		return request(app.getHttpServer())
			.put(`/projects/${createdProject._id}`)
			.send({
				name: newName
			})
			.expect(200) // Todo
			.expect((res) => {
				expect(res.body.name).toBe(newName);
			});
	});

	afterAll(async () => {
		await app.close();
	});

});
